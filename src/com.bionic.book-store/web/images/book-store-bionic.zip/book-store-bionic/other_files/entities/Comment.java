package entities;

/**
 * Created by Eklerka on 7/16/2014.
 */
public class Comment {
}

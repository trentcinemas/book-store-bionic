package entities;

public class UserGroup {
}
